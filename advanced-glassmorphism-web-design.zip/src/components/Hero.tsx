import { motion } from "framer-motion";
import { ArrowRight, MousePointerClick, Gauge, Palette } from "lucide-react";

const STATS = [
  { label: "Завершённых проектов", value: "120+" },
  { label: "Лет на рынке", value: "7" },
  { label: "Средняя оценка клиентов", value: "4.9/5" },
];

export default function Hero() {
  return (
    <section id="top" className="relative mx-auto flex min-h-screen max-w-6xl flex-col justify-center px-4 pt-32 pb-20 sm:px-6">
      <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="chip mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider"
            style={{ color: "var(--accent)" }}
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-75" style={{ background: "var(--accent)" }} />
              <span className="relative inline-flex h-2 w-2 rounded-full" style={{ background: "var(--accent)" }} />
            </span>
            Доступен для новых проектов
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-4xl font-extrabold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl"
            style={{ color: "var(--text-primary)" }}
          >
            Веб-дизайн, который
            <br />
            <span className="text-gradient">выглядит как будущее</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-6 max-w-xl text-base leading-relaxed sm:text-lg"
            style={{ color: "var(--text-secondary)" }}
          >
            Я проектирую и верстаю сайты в стиле стеклянного морфизма: лёгкие,
            быстрые, с живой анимацией и продуманной типографикой. Переключите
            тему ниже — весь интерфейс пересоберётся на лету.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#work"
              className="btn-glow flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold"
              style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))", color: "var(--accent-contrast)" }}
            >
              Смотреть проекты <ArrowRight className="h-4 w-4" />
            </a>
            <a
              href="#contact"
              className="glass glass-hover flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold"
              style={{ color: "var(--text-primary)" }}
            >
              <MousePointerClick className="h-4 w-4" /> Связаться
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-14 grid grid-cols-3 gap-4 sm:max-w-lg"
          >
            {STATS.map((s) => (
              <div key={s.label}>
                <div className="font-display text-2xl font-extrabold sm:text-3xl" style={{ color: "var(--text-primary)" }}>
                  {s.value}
                </div>
                <div className="mt-1 text-xs leading-tight" style={{ color: "var(--text-muted)" }}>
                  {s.label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="relative mx-auto hidden h-[420px] w-full max-w-sm lg:block"
        >
          <div
            className="absolute inset-0 rounded-[2.5rem]"
            style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))", opacity: 0.18, filter: "blur(40px)" }}
          />
          <motion.div
            animate={{ y: [0, -14, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            className="glass-strong absolute left-1/2 top-10 w-64 -translate-x-1/2 rounded-3xl p-5"
          >
            <div className="flex items-center justify-between">
              <Gauge className="h-5 w-5" style={{ color: "var(--accent)" }} />
              <span className="text-xs font-semibold" style={{ color: "var(--text-muted)" }}>
                Performance
              </span>
            </div>
            <div className="mt-4 font-display text-3xl font-extrabold" style={{ color: "var(--text-primary)" }}>
              99 / 100
            </div>
            <div className="mt-3 h-2 w-full overflow-hidden rounded-full" style={{ background: "var(--glass-border)" }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: "99%" }}
                transition={{ duration: 1.4, delay: 0.8 }}
                className="h-full rounded-full"
                style={{ background: "linear-gradient(90deg, var(--accent), var(--accent-2))" }}
              />
            </div>
          </motion.div>

          <motion.div
            animate={{ y: [0, 16, 0] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
            className="glass-strong absolute bottom-6 left-0 w-56 rounded-3xl p-5"
          >
            <Palette className="h-5 w-5" style={{ color: "var(--accent-2)" }} />
            <div className="mt-3 text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
              3 темы оформления
            </div>
            <div className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
              Glassmorphism UI kit
            </div>
            <div className="mt-3 flex -space-x-2">
              {["#60a5fa", "#a855f7", "#f97316"].map((c) => (
                <span key={c} className="h-6 w-6 rounded-full border-2" style={{ background: c, borderColor: "var(--bg-base)" }} />
              ))}
            </div>
          </motion.div>

          <motion.div
            animate={{ y: [0, -10, 0], rotate: [0, 3, 0] }}
            transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
            className="glass-strong absolute bottom-24 right-0 w-40 rounded-3xl p-4 text-center"
          >
            <div className="font-display text-xl font-extrabold" style={{ color: "var(--text-primary)" }}>
              24/7
            </div>
            <div className="text-[11px]" style={{ color: "var(--text-muted)" }}>
              Поддержка проекта
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
