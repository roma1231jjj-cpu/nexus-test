import { useState } from "react";
import { Mail, Send, Phone, MapPin, CheckCircle2 } from "lucide-react";
import Reveal from "./Reveal";

export default function Contact() {
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <section id="contact" className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6">
      <div className="glass-strong grid gap-0 overflow-hidden rounded-[2rem] lg:grid-cols-[0.9fr_1.1fr]">
        <Reveal className="relative flex flex-col justify-between p-9 sm:p-12" y={0}>
          <div>
            <span className="chip inline-block rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--accent)" }}>
              Контакты
            </span>
            <h2 className="font-display mt-5 text-3xl font-extrabold tracking-tight sm:text-4xl" style={{ color: "var(--text-primary)" }}>
              Готовы обсудить ваш проект
            </h2>
            <p className="mt-4 max-w-sm text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
              Расскажите о задаче — отвечу в течение рабочего дня с идеями,
              примерными сроками и стоимостью.
            </p>
          </div>

          <div className="mt-10 space-y-4">
            <div className="flex items-center gap-3 text-sm" style={{ color: "var(--text-secondary)" }}>
              <Mail className="h-4 w-4" style={{ color: "var(--accent)" }} /> hello@lumen.studio
            </div>
            <div className="flex items-center gap-3 text-sm" style={{ color: "var(--text-secondary)" }}>
              <Phone className="h-4 w-4" style={{ color: "var(--accent)" }} /> +7 (900) 123-45-67
            </div>
            <div className="flex items-center gap-3 text-sm" style={{ color: "var(--text-secondary)" }}>
              <MapPin className="h-4 w-4" style={{ color: "var(--accent)" }} /> Удалённо · весь мир
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.1} y={0} className="p-9 sm:p-12">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--text-muted)" }}>
                  Имя
                </label>
                <input
                  required
                  type="text"
                  placeholder="Как к вам обращаться"
                  className="glass w-full rounded-xl px-4 py-3 text-sm outline-none placeholder:opacity-50 focus:ring-2"
                  style={{ color: "var(--text-primary)" }}
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--text-muted)" }}>
                  Email
                </label>
                <input
                  required
                  type="email"
                  placeholder="you@email.com"
                  className="glass w-full rounded-xl px-4 py-3 text-sm outline-none placeholder:opacity-50 focus:ring-2"
                  style={{ color: "var(--text-primary)" }}
                />
              </div>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--text-muted)" }}>
                О проекте
              </label>
              <textarea
                required
                rows={4}
                placeholder="Коротко опишите задачу, сроки и бюджет"
                className="glass w-full resize-none rounded-xl px-4 py-3 text-sm outline-none placeholder:opacity-50 focus:ring-2"
                style={{ color: "var(--text-primary)" }}
              />
            </div>
            <button
              type="submit"
              className="btn-glow flex w-full items-center justify-center gap-2 rounded-xl py-3.5 text-sm font-semibold sm:w-auto sm:px-8"
              style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))", color: "var(--accent-contrast)" }}
            >
              {sent ? (
                <>
                  <CheckCircle2 className="h-4 w-4" /> Отправлено!
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" /> Отправить заявку
                </>
              )}
            </button>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
