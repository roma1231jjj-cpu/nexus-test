import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Menu, X, Sparkles } from "lucide-react";
import ThemeSwitcher from "./ThemeSwitcher";

const LINKS = [
  { href: "#about", label: "О студии" },
  { href: "#skills", label: "Навыки" },
  { href: "#work", label: "Проекты" },
  { href: "#process", label: "Процесс" },
  { href: "#reviews", label: "Отзывы" },
  { href: "#contact", label: "Контакты" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-x-0 top-0 z-50 flex justify-center px-4 pt-4"
    >
      <div
        className={`glass flex w-full max-w-6xl items-center justify-between rounded-2xl px-4 py-3 transition-all duration-500 sm:px-6 ${
          scrolled ? "shadow-2xl" : ""
        }`}
      >
        <a href="#top" className="flex items-center gap-2 font-display text-lg font-bold" style={{ color: "var(--text-primary)" }}>
          <span
            className="relative flex h-9 w-9 items-center justify-center rounded-xl"
            style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}
          >
            <Sparkles className="h-5 w-5" style={{ color: "var(--accent-contrast)" }} />
          </span>
          LUMEN<span style={{ color: "var(--accent)" }}>.</span>studio
        </a>

        <nav className="hidden items-center gap-7 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium opacity-80 transition hover:opacity-100"
              style={{ color: "var(--text-secondary)" }}
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <ThemeSwitcher />
          <a
            href="#contact"
            className="btn-glow rounded-full px-4 py-2 text-sm font-semibold"
            style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))", color: "var(--accent-contrast)" }}
          >
            Обсудить проект
          </a>
        </div>

        <button
          className="flex h-10 w-10 items-center justify-center rounded-xl glass lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Открыть меню"
        >
          {open ? <X className="h-5 w-5" style={{ color: "var(--text-primary)" }} /> : <Menu className="h-5 w-5" style={{ color: "var(--text-primary)" }} />}
        </button>
      </div>

      {open && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass absolute left-4 right-4 top-[72px] flex flex-col gap-4 rounded-2xl p-5 lg:hidden"
        >
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-sm font-medium"
              style={{ color: "var(--text-primary)" }}
            >
              {l.label}
            </a>
          ))}
          <div className="flex items-center justify-between pt-2">
            <ThemeSwitcher compact />
            <a
              href="#contact"
              onClick={() => setOpen(false)}
              className="rounded-full px-4 py-2 text-sm font-semibold"
              style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))", color: "var(--accent-contrast)" }}
            >
              Написать
            </a>
          </div>
        </motion.div>
      )}
    </motion.header>
  );
}
