import { Palette, Zap, ShieldCheck, Layers, Sparkles, Code2 } from "lucide-react";
import Reveal from "./Reveal";

const FEATURES = [
  {
    icon: Palette,
    title: "Дизайн, а не шаблон",
    text: "Каждый интерфейс рисуется с нуля под характер бренда — никаких одинаковых лендингов.",
  },
  {
    icon: Zap,
    title: "Скорость загрузки",
    text: "Оптимизация изображений, ленивая загрузка и чистый код — Lighthouse 95+ на выходе.",
  },
  {
    icon: ShieldCheck,
    title: "Надёжный код",
    text: "TypeScript, тесты и строгая архитектура компонентов для долгой жизни проекта.",
  },
  {
    icon: Layers,
    title: "Адаптивность",
    text: "От часов Apple Watch до 4K-мониторов — верстка остаётся идеальной на любом экране.",
  },
  {
    icon: Sparkles,
    title: "Микроанимации",
    text: "Плавные переходы и отклик на каждое действие пользователя создают ощущение «живого» продукта.",
  },
  {
    icon: Code2,
    title: "Чистая передача кода",
    text: "Документация, Storybook и понятная структура — разработчикам клиента будет комфортно.",
  },
];

export default function Features() {
  return (
    <section id="about" className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <span className="chip inline-block rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--accent)" }}>
            О студии
          </span>
          <h2 className="font-display mt-5 text-3xl font-extrabold tracking-tight sm:text-4xl" style={{ color: "var(--text-primary)" }}>
            Почему клиенты возвращаются снова
          </h2>
          <p className="mt-4 text-base" style={{ color: "var(--text-secondary)" }}>
            Я совмещаю роли дизайнера и разработчика — это убирает испорченный телефон
            между макетом и кодом, а значит, финальный сайт выглядит именно так, как задумано.
          </p>
        </div>
      </Reveal>

      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map((f, i) => (
          <Reveal key={f.title} delay={i * 0.08}>
            <div className="glass glass-hover h-full rounded-3xl p-7">
              <div
                className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl"
                style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}
              >
                <f.icon className="h-6 w-6" style={{ color: "var(--accent-contrast)" }} />
              </div>
              <h3 className="font-display text-lg font-bold" style={{ color: "var(--text-primary)" }}>
                {f.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                {f.text}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
