export default function Background() {
  return (
    <>
      <div className="app-backdrop" />
      <div className="grid-overlay" />
      <div className="noise-overlay" />
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div
          className="blob blob-1 h-[32rem] w-[32rem] -left-40 -top-32"
          style={{ background: "var(--blob-1)" }}
        />
        <div
          className="blob blob-2 h-[28rem] w-[28rem] right-[-10rem] top-10"
          style={{ background: "var(--blob-2)" }}
        />
        <div
          className="blob blob-3 h-[30rem] w-[30rem] left-1/3 bottom-[-14rem]"
          style={{ background: "var(--blob-3)" }}
        />
      </div>
    </>
  );
}
