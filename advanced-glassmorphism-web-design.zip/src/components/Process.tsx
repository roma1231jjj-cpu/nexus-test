import { Search, PenTool, Code2, Rocket } from "lucide-react";
import Reveal from "./Reveal";

const STEPS = [
  { icon: Search, step: "01", title: "Исследование", text: "Разбираю задачу, аудиторию и конкурентов, формирую структуру и UX-карту." },
  { icon: PenTool, step: "02", title: "Дизайн", text: "Создаю UI-кит и прототипы в Figma, согласовываю стиль и анимации." },
  { icon: Code2, step: "03", title: "Разработка", text: "Верстаю на React + TypeScript с адаптивом, доступностью и чистой архитектурой." },
  { icon: Rocket, step: "04", title: "Запуск", text: "Тестирую, оптимизирую производительность и публикую с поддержкой после релиза." },
];

export default function Process() {
  return (
    <section id="process" className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <span className="chip inline-block rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--accent)" }}>
            Процесс
          </span>
          <h2 className="font-display mt-5 text-3xl font-extrabold tracking-tight sm:text-4xl" style={{ color: "var(--text-primary)" }}>
            Четыре шага от идеи до релиза
          </h2>
        </div>
      </Reveal>

      <div className="relative mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div
          className="pointer-events-none absolute left-0 right-0 top-12 hidden h-px lg:block"
          style={{ background: "var(--divider)" }}
        />
        {STEPS.map((s, i) => (
          <Reveal key={s.step} delay={i * 0.1}>
            <div className="glass glass-hover relative h-full rounded-3xl p-7">
              <div className="flex items-center justify-between">
                <div
                  className="flex h-12 w-12 items-center justify-center rounded-2xl"
                  style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}
                >
                  <s.icon className="h-6 w-6" style={{ color: "var(--accent-contrast)" }} />
                </div>
                <span className="font-display text-3xl font-extrabold opacity-20" style={{ color: "var(--text-primary)" }}>
                  {s.step}
                </span>
              </div>
              <h3 className="font-display mt-5 text-lg font-bold" style={{ color: "var(--text-primary)" }}>
                {s.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                {s.text}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
