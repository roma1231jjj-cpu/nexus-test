import { THEMES, useTheme, type ThemeId } from "../theme";
import { Check } from "lucide-react";

export default function ThemeSwitcher({ compact = false }: { compact?: boolean }) {
  const { themeId, setThemeId } = useTheme();
  const order: ThemeId[] = ["aurora", "nebula", "ember"];

  return (
    <div className={`flex items-center gap-2 ${compact ? "" : "glass rounded-full px-2 py-2"}`}>
      {order.map((id) => {
        const t = THEMES[id];
        const active = themeId === id;
        return (
          <button
            key={id}
            onClick={() => setThemeId(id)}
            title={`${t.name} — ${t.tagline}`}
            aria-label={`Переключить на тему ${t.name}`}
            className={`group relative flex h-8 w-8 items-center justify-center rounded-full border transition-all duration-300 ${
              active ? "scale-110 border-white/70 shadow-lg" : "border-white/20 hover:scale-105"
            }`}
            style={{
              background: `conic-gradient(from 180deg, ${t.swatch[0]}, ${t.swatch[1]}, ${t.swatch[2]})`,
            }}
          >
            {active && (
              <span className="absolute inset-0 flex items-center justify-center rounded-full bg-black/20">
                <Check className="h-4 w-4 text-white drop-shadow" strokeWidth={3} />
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
