import { Sparkles, Globe, AtSign, MessageCircle, Send, ArrowUp } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative mx-auto max-w-6xl px-4 pb-10 pt-6 sm:px-6">
      <div className="glass flex flex-col items-center gap-6 rounded-3xl px-6 py-8 sm:flex-row sm:justify-between">
        <a href="#top" className="flex items-center gap-2 font-display text-base font-bold" style={{ color: "var(--text-primary)" }}>
          <span
            className="flex h-8 w-8 items-center justify-center rounded-lg"
            style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}
          >
            <Sparkles className="h-4 w-4" style={{ color: "var(--accent-contrast)" }} />
          </span>
          LUMEN.studio
        </a>

        <p className="text-center text-xs sm:text-sm" style={{ color: "var(--text-muted)" }}>
          © {new Date().getFullYear()} Lumen Studio. Сделано с любовью к стеклу и анимации.
        </p>

        <div className="flex items-center gap-3">
          {[Globe, AtSign, MessageCircle, Send].map((Icon, i) => (
            <a
              key={i}
              href="#"
              className="glass-hover flex h-9 w-9 items-center justify-center rounded-full"
              style={{ color: "var(--text-secondary)" }}
            >
              <Icon className="h-4 w-4" />
            </a>
          ))}
          <a
            href="#top"
            className="flex h-9 w-9 items-center justify-center rounded-full"
            style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))", color: "var(--accent-contrast)" }}
            aria-label="Наверх"
          >
            <ArrowUp className="h-4 w-4" />
          </a>
        </div>
      </div>
    </footer>
  );
}
