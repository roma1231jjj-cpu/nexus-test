import { motion } from "framer-motion";
import Reveal from "./Reveal";

const SKILLS = [
  { label: "UI / UX дизайн", value: 96 },
  { label: "Frontend (React / TS)", value: 94 },
  { label: "Анимация и интерактив", value: 90 },
  { label: "Производительность и SEO", value: 88 },
];

const BADGES = [
  { value: "150+", label: "Компонентов в библиотеке" },
  { value: "40мс", label: "Среднее время отклика UI" },
  { value: "100%", label: "Адаптивная верстка" },
];

export default function Skills() {
  return (
    <section id="skills" className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6">
      <div className="grid gap-14 lg:grid-cols-2 lg:items-center">
        <Reveal>
          <span className="chip inline-block rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--accent)" }}>
            Навыки
          </span>
          <h2 className="font-display mt-5 text-3xl font-extrabold tracking-tight sm:text-4xl" style={{ color: "var(--text-primary)" }}>
            Инструменты, которыми
            <br />я довожу идею до пикселя
          </h2>
          <p className="mt-4 max-w-md text-base" style={{ color: "var(--text-secondary)" }}>
            От первого скетча в Figma до продакшн-сборки на Vite — полный цикл
            в одних руках, без потери качества на стыках.
          </p>

          <div className="mt-10 grid grid-cols-3 gap-4">
            {BADGES.map((b) => (
              <div key={b.label} className="glass rounded-2xl p-4 text-center">
                <div className="font-display text-xl font-extrabold sm:text-2xl" style={{ color: "var(--text-primary)" }}>
                  {b.value}
                </div>
                <div className="mt-1 text-[11px] leading-tight" style={{ color: "var(--text-muted)" }}>
                  {b.label}
                </div>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="glass-strong rounded-3xl p-8">
            <div className="space-y-7">
              {SKILLS.map((s, i) => (
                <div key={s.label}>
                  <div className="mb-2 flex items-center justify-between text-sm font-semibold">
                    <span style={{ color: "var(--text-primary)" }}>{s.label}</span>
                    <span style={{ color: "var(--accent)" }}>{s.value}%</span>
                  </div>
                  <div className="h-2.5 w-full overflow-hidden rounded-full" style={{ background: "var(--glass-border)" }}>
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${s.value}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.1, delay: i * 0.1, ease: "easeOut" }}
                      className="h-full rounded-full"
                      style={{ background: "linear-gradient(90deg, var(--accent), var(--accent-2))" }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
