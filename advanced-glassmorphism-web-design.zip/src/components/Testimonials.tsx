import { Star, Quote } from "lucide-react";
import Reveal from "./Reveal";

const REVIEWS = [
  {
    name: "Анна Светлова",
    role: "CEO, Pulse Analytics",
    text: "Получили не просто сайт, а полноценный продукт. Переключение тем в духе glassmorphism впечатлило всю команду инвесторов.",
    initials: "АС",
  },
  {
    name: "Дмитрий Орлов",
    role: "Founder, Nova Wallet",
    text: "Скорость и внимание к деталям — на высоте. Анимации лёгкие, ничего не тормозит даже на слабых телефонах.",
    initials: "ДО",
  },
  {
    name: "Марина Ким",
    role: "Marketing Lead, Ember Market",
    text: "Конверсия на лендинге выросла почти на треть после редизайна. Отдельное спасибо за адаптивность и скорость загрузки.",
    initials: "МК",
  },
];

export default function Testimonials() {
  return (
    <section id="reviews" className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <span className="chip inline-block rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--accent)" }}>
            Отзывы
          </span>
          <h2 className="font-display mt-5 text-3xl font-extrabold tracking-tight sm:text-4xl" style={{ color: "var(--text-primary)" }}>
            Что говорят клиенты
          </h2>
        </div>
      </Reveal>

      <div className="mt-14 grid gap-6 lg:grid-cols-3">
        {REVIEWS.map((r, i) => (
          <Reveal key={r.name} delay={i * 0.1}>
            <div className="glass glass-hover relative h-full rounded-3xl p-7">
              <Quote className="h-8 w-8 opacity-20" style={{ color: "var(--accent)" }} />
              <div className="mt-4 flex gap-1">
                {Array.from({ length: 5 }).map((_, idx) => (
                  <Star key={idx} className="h-4 w-4 fill-current" style={{ color: "var(--accent)" }} />
                ))}
              </div>
              <p className="mt-4 text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                «{r.text}»
              </p>
              <div className="mt-6 flex items-center gap-3">
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold"
                  style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))", color: "var(--accent-contrast)" }}
                >
                  {r.initials}
                </div>
                <div>
                  <div className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
                    {r.name}
                  </div>
                  <div className="text-xs" style={{ color: "var(--text-muted)" }}>
                    {r.role}
                  </div>
                </div>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
