const ITEMS = [
  "React", "TypeScript", "Tailwind CSS", "Framer Motion", "Figma",
  "Next.js", "Node.js", "GraphQL", "WebGL", "Three.js", "Vite", "Supabase",
];

export default function Marquee() {
  const loop = [...ITEMS, ...ITEMS];
  return (
    <div className="relative z-10 my-4 overflow-hidden py-6">
      <div className="divider-line absolute inset-x-0 top-0 h-px" />
      <div className="divider-line absolute inset-x-0 bottom-0 h-px" />
      <div className="flex w-max gap-10 marquee-track">
        {loop.map((item, i) => (
          <span
            key={i}
            className="font-display flex items-center gap-3 text-xl font-semibold opacity-60 sm:text-2xl"
            style={{ color: "var(--text-secondary)" }}
          >
            {item}
            <span style={{ color: "var(--accent)" }}>•</span>
          </span>
        ))}
      </div>
    </div>
  );
}
