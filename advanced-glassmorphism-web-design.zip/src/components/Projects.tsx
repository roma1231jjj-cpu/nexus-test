import { ArrowUpRight } from "lucide-react";
import Reveal from "./Reveal";

const PROJECTS = [
  {
    title: "Pulse Analytics",
    tag: "SaaS Dashboard",
    img: "/images/project-dashboard.jpg",
    desc: "Панель аналитики реального времени со стеклянными виджетами и живыми графиками.",
  },
  {
    title: "Nova Wallet",
    tag: "Fintech App",
    img: "/images/project-fintech.jpg",
    desc: "Мобильное приложение для управления криптоактивами с фиолетовым неоновым стеклом.",
  },
  {
    title: "Ember Market",
    tag: "E-commerce",
    img: "/images/project-ecommerce.jpg",
    desc: "Премиальная витрина товаров с тёплыми акцентами и плавными микровзаимодействиями.",
  },
  {
    title: "Teal Identity",
    tag: "Brand Design",
    img: "/images/project-brand.jpg",
    desc: "Фирменный стиль и презентация бренда в сдержанной бирюзовой палитре.",
  },
];

export default function Projects() {
  return (
    <section id="work" className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6">
      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <span className="chip inline-block rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--accent)" }}>
              Избранные проекты
            </span>
            <h2 className="font-display mt-5 max-w-lg text-3xl font-extrabold tracking-tight sm:text-4xl" style={{ color: "var(--text-primary)" }}>
              Работы, в которых дизайн и код говорят на одном языке
            </h2>
          </div>
          <p className="max-w-sm text-sm" style={{ color: "var(--text-secondary)" }}>
            Каждый кейс — это не просто картинка, а рабочий интерфейс с анимацией,
            адаптивом и вниманием к деталям вплоть до состояний hover и focus.
          </p>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-6 sm:grid-cols-2">
        {PROJECTS.map((p, i) => (
          <Reveal key={p.title} delay={i * 0.1}>
            <a href="#contact" className="group glass glass-hover relative block overflow-hidden rounded-3xl">
              <div className="relative h-64 w-full overflow-hidden sm:h-72">
                <img
                  src={p.img}
                  alt={p.title}
                  className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                  loading="lazy"
                />
                <div
                  className="absolute inset-0 opacity-70"
                  style={{ background: "linear-gradient(180deg, transparent 20%, rgba(0,0,0,0.75) 100%)" }}
                />
                <span
                  className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full glass-strong opacity-0 transition-all duration-300 group-hover:opacity-100 group-hover:rotate-45"
                >
                  <ArrowUpRight className="h-5 w-5" style={{ color: "var(--text-primary)" }} />
                </span>
                <div className="absolute inset-x-0 bottom-0 p-6">
                  <span className="text-xs font-semibold uppercase tracking-wider text-white/70">{p.tag}</span>
                  <h3 className="font-display mt-1 text-xl font-bold text-white sm:text-2xl">{p.title}</h3>
                  <p className="mt-2 max-w-xs text-sm text-white/75">{p.desc}</p>
                </div>
              </div>
            </a>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
