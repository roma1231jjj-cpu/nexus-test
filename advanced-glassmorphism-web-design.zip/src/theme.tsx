import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type ThemeId = "aurora" | "nebula" | "ember";

export interface ThemeDefinition {
  id: ThemeId;
  name: string;
  tagline: string;
  swatch: [string, string, string];
  vars: Record<string, string>;
  bodyClass: string;
}

export const THEMES: Record<ThemeId, ThemeDefinition> = {
  aurora: {
    id: "aurora",
    name: "Aurora",
    tagline: "Бело-синее стекло",
    swatch: ["#eff6ff", "#3b82f6", "#06b6d4"],
    bodyClass: "theme-aurora",
    vars: {
      "--bg-base": "#eef3fb",
      "--bg-gradient":
        "radial-gradient(circle at 15% 10%, rgba(99,160,255,0.35), transparent 45%), radial-gradient(circle at 85% 20%, rgba(56,189,248,0.3), transparent 50%), radial-gradient(circle at 50% 90%, rgba(129,140,248,0.25), transparent 55%), linear-gradient(180deg, #f5f9ff 0%, #eaf1fc 45%, #e3ecfb 100%)",
      "--blob-1": "#60a5fa",
      "--blob-2": "#22d3ee",
      "--blob-3": "#818cf8",
      "--text-primary": "#0f172a",
      "--text-secondary": "#475569",
      "--text-muted": "#64748b",
      "--accent": "#2563eb",
      "--accent-2": "#06b6d4",
      "--accent-contrast": "#ffffff",
      "--glass-bg": "rgba(255,255,255,0.55)",
      "--glass-bg-strong": "rgba(255,255,255,0.75)",
      "--glass-border": "rgba(255,255,255,0.75)",
      "--glass-shadow": "0 8px 32px rgba(59,130,246,0.18)",
      "--nav-bg": "rgba(255,255,255,0.6)",
      "--chip-bg": "rgba(37,99,235,0.08)",
      "--ring": "rgba(37,99,235,0.35)",
      "--divider": "rgba(15,23,42,0.08)",
      "--grid-line": "rgba(37,99,235,0.08)",
    },
  },
  nebula: {
    id: "nebula",
    name: "Nebula",
    tagline: "Чёрно-фиолетовое стекло",
    swatch: ["#0b0615", "#7c3aed", "#d946ef"],
    bodyClass: "theme-nebula",
    vars: {
      "--bg-base": "#07040f",
      "--bg-gradient":
        "radial-gradient(circle at 20% 15%, rgba(124,58,237,0.45), transparent 45%), radial-gradient(circle at 80% 10%, rgba(217,70,239,0.3), transparent 50%), radial-gradient(circle at 50% 100%, rgba(59,7,100,0.6), transparent 60%), linear-gradient(180deg, #0a0414 0%, #0d0620 45%, #06030d 100%)",
      "--blob-1": "#8b5cf6",
      "--blob-2": "#d946ef",
      "--blob-3": "#4c1d95",
      "--text-primary": "#f5f3ff",
      "--text-secondary": "#c4b5fd",
      "--text-muted": "#9d8fc7",
      "--accent": "#a855f7",
      "--accent-2": "#ec4899",
      "--accent-contrast": "#0b0615",
      "--glass-bg": "rgba(255,255,255,0.06)",
      "--glass-bg-strong": "rgba(255,255,255,0.1)",
      "--glass-border": "rgba(255,255,255,0.14)",
      "--glass-shadow": "0 8px 32px rgba(168,85,247,0.25)",
      "--nav-bg": "rgba(10,5,20,0.55)",
      "--chip-bg": "rgba(168,85,247,0.15)",
      "--ring": "rgba(168,85,247,0.5)",
      "--divider": "rgba(255,255,255,0.1)",
      "--grid-line": "rgba(168,85,247,0.12)",
    },
  },
  ember: {
    id: "ember",
    name: "Ember",
    tagline: "Авторское сочетание",
    swatch: ["#140a06", "#f97316", "#f43f5e"],
    bodyClass: "theme-ember",
    vars: {
      "--bg-base": "#0e0805",
      "--bg-gradient":
        "radial-gradient(circle at 20% 20%, rgba(249,115,22,0.35), transparent 45%), radial-gradient(circle at 85% 15%, rgba(244,63,94,0.3), transparent 50%), radial-gradient(circle at 50% 100%, rgba(120,53,15,0.5), transparent 60%), linear-gradient(180deg, #120a06 0%, #170b07 45%, #0c0604 100%)",
      "--blob-1": "#f97316",
      "--blob-2": "#f43f5e",
      "--blob-3": "#eab308",
      "--text-primary": "#fff7ed",
      "--text-secondary": "#fdba74",
      "--text-muted": "#d6a67a",
      "--accent": "#fb923c",
      "--accent-2": "#f43f5e",
      "--accent-contrast": "#140a06",
      "--glass-bg": "rgba(255,255,255,0.06)",
      "--glass-bg-strong": "rgba(255,255,255,0.1)",
      "--glass-border": "rgba(251,191,36,0.18)",
      "--glass-shadow": "0 8px 32px rgba(249,115,22,0.25)",
      "--nav-bg": "rgba(15,8,5,0.55)",
      "--chip-bg": "rgba(251,146,60,0.15)",
      "--ring": "rgba(251,146,60,0.5)",
      "--divider": "rgba(255,255,255,0.1)",
      "--grid-line": "rgba(251,146,60,0.12)",
    },
  },
};

interface ThemeContextValue {
  themeId: ThemeId;
  theme: ThemeDefinition;
  setThemeId: (id: ThemeId) => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [themeId, setThemeId] = useState<ThemeId>("nebula");
  const theme = THEMES[themeId];

  useEffect(() => {
    const root = document.documentElement;
    Object.entries(theme.vars).forEach(([key, value]) => {
      root.style.setProperty(key, value);
    });
    document.body.className = theme.bodyClass;
  }, [theme]);

  const value = useMemo(() => ({ themeId, theme, setThemeId }), [themeId, theme]);

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
